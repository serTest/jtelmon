public abstract interface KeyClient{
    public void keySelected(Object key);
}
