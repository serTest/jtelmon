import java.awt.Component;
public abstract interface  CellEditorWidget {

    public abstract void setWidgetValue(Object o);
    public abstract Object getWidgetValue();
}
