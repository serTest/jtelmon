// this has been obsoleted by PropertyChange machinery
public abstract interface TableChangeListener{
    public void tableChanged(TableChangeEvent e);
}
