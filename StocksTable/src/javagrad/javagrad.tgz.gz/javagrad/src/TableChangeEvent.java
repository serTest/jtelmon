/**
 * This class is just a placeholder at the moment to make 
 * it cleaner to change the API later.
 *
 * @author <a href="mailto:bremner@unb.ca">David Bremner</a>
 * @version 1.0
 */
public class TableChangeEvent{
    public TableChangeEvent(){
	// do nothing
    }
}
