public abstract interface RowClient{
    public void rowSelected(int row);
}
